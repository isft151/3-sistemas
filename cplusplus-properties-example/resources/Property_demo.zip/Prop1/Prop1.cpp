// Prop1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Prop1.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif
#include "Property.hpp"

// The one and only application object

CWinApp theApp;

using namespace std;

class PropTest
{
public:
  PropTest()
  {
    Count.setContainer(this);
    Count.setter(&PropTest::setCount);
    Count.getter(&PropTest::getCount);
  }
  int getCount(){return m_nCount;}
  void setCount(int nCount){ m_nCount = nCount;}

  property<PropTest,int,READ_WRITE> Count;
private:
  int m_nCount;
};

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		_tprintf(_T("Fatal Error: MFC initialization failed\n"));
		nRetCode = 1;
	}
	else
	{
    int i=5,j;
    PropTest test;

    test.Count = i;
    j = test.Count;
    cout << j;
  }

	return nRetCode;
}
